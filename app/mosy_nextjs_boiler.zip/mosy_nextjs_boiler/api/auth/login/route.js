import { mosyFlexSelect , mmres , base64Encode, mosySecureSelect, mosySqlUpdate, magicRandomStr } from '../../apiUtils/dataControl/dataUtils';
import { connectDB, activeDB } from '../../apiUtils/dataControl/conn';
import saAuthConfigs from '../../../auth/featureConfig/saAuthConfigs';
import { generateAuthToken } from '../authManager';

// Make sure the payment_account column exists (checked once per server process).
let paymentAccountReady = false;
async function ensurePaymentAccountColumn(table) {
  if (paymentAccountReady) return;
  const conn = await connectDB();
  try {
    const [cols] = await conn.execute(
      'SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
      [activeDB, table, 'payment_account']
    );
    if (cols.length === 0) {
      await conn.query(`ALTER TABLE \`${activeDB}\`.\`${table}\` ADD COLUMN \`payment_account\` VARCHAR(50) NULL`);
    }
    paymentAccountReady = true;
  } finally {
    await conn.end();
  }
}

export async function POST(loginAuth) {
  const oauthTable = saAuthConfigs.oauthTable;
  const usernameCol = saAuthConfigs.usernameCol;
  const emailCol = saAuthConfigs.emailCol;
  const passwordCol = saAuthConfigs.passwordCol;
  const sessionColumns = saAuthConfigs.sessionColumns

  try {
    let body = {};
    const contentType = loginAuth.headers.get('content-type') || '';
    const isMultipart = contentType.includes('multipart/form-data');

    if (isMultipart) {
      const formData = await loginAuth.formData();
      for (let [key, value] of formData.entries()) {
        body[key] = value;
      }
    } else {
      body = await loginAuth.json();
    }

    const authLoginAction = body.auth_mosy_action;
    const authLoginUsername = body.txt_username;
    const authLoginPassword = body.txt_password;
    

    if (authLoginAction === 'auth_login') {
      // Protect against SQL injection-ish: escape single quotes
      const safeUsername = mmres(authLoginUsername);
      const safePassword = mmres(authLoginPassword)

      const loginQuery = `WHERE ${emailCol} = '${safeUsername}' AND ${passwordCol} = '${safePassword}'`
      
      console.log("loginQuery "+loginQuery)
      const enhancedParams = {
        tbl: oauthTable,
        colstr: base64Encode(sessionColumns), // base64 of '*'
        q: base64Encode(loginQuery),
      };

      await ensurePaymentAccountColumn(oauthTable);
      const result = await mosyFlexSelect(enhancedParams);

      if (!result?.data || result.data.length === 0) {
        return Response.json(
          {
            status: 'error',
            message: 'Invalid username or password',
          },
          { status: 403 }
        );
      }

      console.log(`loginresult`, result)
      // First login for a site with no payment_account: generate one and share it
      // with every user of that site, then use it for the billing account.
      const siteId = result.data[0].hive_site_id;
      if (siteId && !result.data[0].payment_account) {
        const safeSiteId = mmres(String(siteId));
        // only fills rows still empty, so a concurrent login can't overwrite it
        await mosySqlUpdate(
          oauthTable,
          { payment_account: magicRandomStr(12) },
          {},
          `hive_site_id='${safeSiteId}' AND (payment_account IS NULL OR payment_account='')`
        );
        const refreshed = await mosyFlexSelect({
          tbl: oauthTable,
          colstr: base64Encode('payment_account'),
          q: base64Encode(`WHERE hive_site_id='${safeSiteId}' AND payment_account<>'' LIMIT 1`),
        });
        result.data[0].payment_account = refreshed?.data?.[0]?.payment_account ?? null;
      }

      const userRolesQuery = await mosySecureSelect({batchMutations:{},dictionary:{roleId:`role_id`,bundleId:`bundle_id`},table:'user_bundle_role_functions',searchParams:{bundleId: btoa(result.data[0].user_role)}}) 
      
      const userData = { ...result.data[0], userRoles: userRolesQuery.data };
      
      const authToken =generateAuthToken(userData)

      // Remove the password field
      delete userData[passwordCol];

      return Response.json({
        status: 'success',
        message: `Login successful`,
        accessToken : authToken,
        user: userData
      });
      
    }

    return Response.json(
      {
        status: 'error',
        message: `Invalid action: ${authLoginAction}`,
      },
      { status: 400 }
    );
  } catch (err) {
    console.error('Request failed:', err);
    return Response.json(
      {
        status: 'error',
        message: `Data post error: ${err.message}`,
      },
      { status: 500 }
    );
  }
}