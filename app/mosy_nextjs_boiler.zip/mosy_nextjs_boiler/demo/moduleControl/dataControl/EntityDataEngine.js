// EntityDataEngine — the actual "kitchen." Zero React. Zero DOM. Zero UI knowledge.
// Any UI (React, plain HTML/JS, Vue, a downloaded jQuery dashboard) can use this
// by creating one instance and calling .subscribe() to get notified when data changes.

import { mosyGetData, mosyPostData } from '../../../MosyUtils/hiveUtils';
import { runRegisteredAction, normalizeActionResult } from '../logicControl/actionsRegistry';
// normalizeActionResult used to be duplicated here (byte-for-byte, easy to
// drift out of sync with the copy actionsRegistry.jsx itself exports and
// useEntityGridController.jsx's dispatchAction() uses) — now a single
// shared definition backs both call paths.

export class EntityDataEngine {
  constructor(schema, options = {}) {
    this.schema = schema;
    this.fixedQuery = options.fixedQuery || {};
    // The { key: fn } registry a module wires up (actionsRegistry.js's
    // exported object) — needed so runAction()/runRowAction() below can
    // actually invoke the real handler instead of silently no-op'ing.
    // Constructor-time snapshot, same convention as fixedQuery above:
    // this engine instance is built once per useEntityController() call
    // and never rebuilt on a later render, so there's no live prop to
    // resync here.
    this.moduleActions = options.moduleActions || {};

    this.state = {
      rows: [],
      loading: true,
      error: null,
      page: 1,
      pageCount: 1,
      pageSize: options.defaultPageSize || 20,
      search: '',
      activeFilter: schema.filters?.[0]?.key || null,
      presetQuery: schema.filters?.[0]?.query || {},   // from a filters[] button
      advancedQuery: {},                                 // from advancedFilters[] inputs (user_id, date range...)
    };

    this.listeners = new Set();

    // mosyGetData/mosyPostData wrap plain fetch() and don't accept an
    // AbortSignal, so we can't cancel an in-flight request at the network
    // level anymore. Instead every load() stamps a request id; when a
    // response comes back we only apply it if it's still the most recent
    // request. This gives the same "fast filter click wins over a slower,
    // older response" guarantee the old AbortController did.
    this._requestId = 0;
    this._searchDebounce = null;
  }

  // ---- Pub/sub: any UI subscribes here to know when to re-render ----
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener); // call this to unsubscribe
  }

  _setState(partial) {
    this.state = { ...this.state, ...partial };
    this.listeners.forEach((fn) => fn(this.state));
  }

  getState() {
    return this.state;
  }

  // ---- Response normalizer ----
  // mosyGetData / mosyPostData are inconsistent about what they hand back:
  //   - happy path            -> already-parsed JSON, e.g. { status: 'success', data, pagination }
  //   - logical failure       -> parsed JSON too, but status !== 'success'
  //   - network-level failure (res.ok === false) -> the RAW, un-jsoned
  //     Response object (see hiveUtils.jsx: `if (!res.ok) return res;`)
  //   - thrown/network error inside mosyGetData's own try/catch -> it
  //     already catches that and returns { status: 'error', message, data: [] }
  // Every call site below funnels through here so the rest of the engine
  // only ever deals with one shape: { ok, message, data, pagination }.
  async _resolveMosyResult(result) {
    if (typeof Response !== 'undefined' && result instanceof Response) {
      let body = null;
      try {
        body = await result.json();
      } catch {
        // no JSON body to parse — fall through with body = null
      }
      return {
        ok: false,
        message: body?.message || `Request failed (${result.status} ${result.statusText || ''})`.trim(),
        data: body?.data ?? [],
        pagination: body?.pagination,
      };
    }

    const ok = result?.status === 'success';
    return {
      ok,
      message: result?.message || (ok ? '' : 'Something went wrong. Please try again.'),
      data: result?.data ?? (Array.isArray(result) ? result : []),
      pagination: result?.pagination,
    };
  }

  // ---- Data loading ----
  async load() {
    const requestId = ++this._requestId;

    this._setState({ loading: true, error: null });

    // Param names MUST match mosySecureSelect's RESERVED_PARAMS exactly:
    // pageNo = which page, pageSize = rows per page.
    const params = {
      pageNo: this.state.page,
      pageSize: this.state.pageSize,
      searchAny: btoa(this.state.search || ''),
      ...this.state.presetQuery,     // e.g. status=active from a filter button
      ...this.state.advancedQuery,   // e.g. user_id=2, shop_id=3, created_at_start=x, created_at_end=y
      ...this.fixedQuery,

    };

    const raw = await mosyGetData({
      endpoint: this.schema.apiBase,
      params,
    });

    // A newer load() has since fired (filter click, page change, etc.) —
    // this response is stale, drop it silently instead of clobbering
    // whatever the newer request already set.
    if (requestId !== this._requestId) return;

    const { ok, message, data, pagination } = await this._resolveMosyResult(raw);

    this._setState({
      rows: Array.isArray(data) ? data : [],
      pageCount: pagination?.page_count ?? pagination?.pageCount ?? 1,
      loading: false,
      error: ok ? null : message,
    });
  }

  // ---- Fetch one record by id (for edit/profile forms) ----
  async getOne(id) {
    const raw = await mosyGetData({
      endpoint: this.schema.apiBase,
      params: { Node: id },
    });

    const { ok, message, data } = await this._resolveMosyResult(raw);

    if (!ok) {
      console.error('getOne failed:', message);
      return null;
    }

    return Array.isArray(data) ? data[0] ?? null : data ?? null;
  }

  // ---- Preset filter buttons (filters[]) ----
  applyFilter(filterKey) {
    const filter = this.schema.filters?.find((f) => f.key === filterKey);
    if (!filter) return;
    this._setState({ activeFilter: filterKey, presetQuery: filter.query, page: 1 });
    this.load();
  }

  // ---- Runtime filter inputs (advancedFilters[]) ----
  // Set one value: engine.setFilterValue('user_id', 2) or engine.setFilterValue('shop_id', 3)
  setFilterValue(key, value) {
    const advancedQuery = { ...this.state.advancedQuery };
    if (value === '' || value === null || value === undefined) {
      delete advancedQuery[key];
    } else {
      advancedQuery[key] = value;
    }
    this._setState({ advancedQuery, page: 1 });
    this.load();
  }

  // Reads better at call sites: engine.filter('user_id', 12)
  filter(key, value) {
    this.setFilterValue(key, value);
  }

  // Date range helper: engine.setDateRange('created_at', '2024-01-01', '2024-01-31')
  // Produces created_at_start / created_at_end — matches mosySecureSelect's suffix convention.
  setDateRange(key, start, end) {
    const advancedQuery = { ...this.state.advancedQuery };
    if (start) advancedQuery[`${key}_start`] = start; else delete advancedQuery[`${key}_start`];
    if (end) advancedQuery[`${key}_end`] = end; else delete advancedQuery[`${key}_end`];
    this._setState({ advancedQuery, page: 1 });
    this.load();
  }

  // Replaces advancedQuery ENTIRELY in one state update / one load() —
  // deliberately separate from setFilterValue/filter above, which always
  // MERGES (correct for things like a sidebar with several simultaneous
  // inputs — user_id AND a date range together). This is for the
  // opposite case: picking ONE new "smart filter" (tag/map/date) should
  // by default REPLACE whatever filter was active before, not silently
  // AND against it — two unrelated filters stacking can zero out
  // results with no visible explanation, which looks like "the filter
  // is broken" rather than "two filters are combined." Pass
  // { merge: true } to opt into the old additive behavior for a
  // specific call site that genuinely wants simultaneous filters.
  setAdvancedQuery(query, { merge = false } = {}) {
    const advancedQuery = merge ? { ...this.state.advancedQuery, ...query } : { ...query };
    this._setState({ advancedQuery, page: 1 });
    this.load();
  }

  clearFilterValue(key) {
    this.setFilterValue(key, null);
  }

  clearAllAdvancedFilters() {
    this._setState({ advancedQuery: {}, page: 1 });
    this.load();
  }

  setSearch(value) {
    this._setState({ search: value });
    clearTimeout(this._searchDebounce);
    this._searchDebounce = setTimeout(() => {
      this._setState({ page: 1 });
      this.load();
    }, 300); // debounced — waits for typing to pause before hitting the API
  }

  setPage(page) {
    this._setState({ page });
    this.load();
  }

  // Change how many rows come back per page. Resets to page 1, same as
  // any other filter change — staying on "page 7" after switching to
  // 500-rows-per-page would likely be past the end of the new result set.
  setPageSize(size) {
    const parsed = parseInt(size, 10);
    if (!Number.isFinite(parsed) || parsed <= 0) return; // guard against NaN/invalid input ever reaching the API
    this._setState({ pageSize: parsed, page: 1 });
    this.load();
  }

  // ---- Convenience wrappers — UI code never computes page math or
  // repeats the "clear search + reload" sequence itself ----
  //
  // fixedQueryOverride is optional. Passed, it REPLACES this.fixedQuery
  // before reloading — the one legitimate way to change scope after
  // construction, since fixedQuery is otherwise a constructor-time
  // snapshot (useEntityController's engineRef is only ever created once;
  // changing the `fixedQuery` prop on a later render does NOT by itself
  // reach the already-built engine instance). Omitted, behavior is
  // unchanged: clear search, reload page 1, current scope untouched.
  //
  // Second param is opt-in: { clearAdvanced: true } ALSO drops
  // advancedQuery in the SAME state update (one load(), not two) — this
  // is the public "Refresh" button's job (a real "start over"). The
  // internal reload() used after every mutation never passes this, so
  // saving/deleting/updating a row never silently wipes someone's active
  // filter as a side effect.
  refresh(fixedQueryOverride, { clearAdvanced = false } = {}) {
    if (fixedQueryOverride !== undefined) this.fixedQuery = fixedQueryOverride || {};
    const patch = { search: '', page: 1 };
    if (clearAdvanced) patch.advancedQuery = {};
    this._setState(patch);
    this.load();
  }

  nextPage() {
    if (this.state.page < this.state.pageCount) this.setPage(this.state.page + 1);
  }

  prevPage() {
    if (this.state.page > 1) this.setPage(this.state.page - 1);
  }

  // ---- CRUD ----
  // All three mutations return { ok, message } so calling UI (a form's
  // onSubmit, a delete-confirm dialog, etc.) can show a real error message
  // and decide whether to close/reset itself, instead of assuming success.

  // mosyPostData's default JSON transport silently drops any File object
  // (JSON.stringify turns it into {}) — but mosyPostData already has an
  // isMultipart flag that builds real FormData for us (and, importantly,
  // still attaches the auth Authorization header and 403 session
  // handling, which a hand-rolled fetch() would have missed). No need to
  // reinvent that here — just flip the flag whenever values contains a
  // File.
  _hasFile(values) {
    return Object.values(values).some((v) => typeof File !== 'undefined' && v instanceof File);
  }

  async create(values) {
    const raw = await mosyPostData({
      url: `${this.schema.apiBase}`,
      data: values,
      isMultipart: this._hasFile(values),
    });
    const { ok, message } = await this._resolveMosyResult(raw);

    // Success responses look like { status:'success', message, sites_dataNode: 26 }
    // — the key is `${entity}_dataNode`, same alias used everywhere else
    // (route.js's DELETE handler, CompaniesProfile's searchParams.get()).
    // On the failure path `raw` may be the raw un-jsoned Response object
    // (see _resolveMosyResult), so only read this off `raw` when ok.
    const dataNodeKey = `${this.schema.entity}_dataNode`;
    const newId = ok ? raw?.[dataNodeKey] : undefined;

    if (ok) {
      await this.load();
    } else {
      this._setState({ error: message });
    }

    return { ok, message, id: newId };
  }

  async update(id, values) {
    const payload = { [`${this.schema.entity}_dataNode`]: id, ...values };
    const raw = await mosyPostData({
      url: `${this.schema.apiBase}`,
      data: payload,
      method: 'PUT',
      isMultipart: this._hasFile(values),
    });


    console.log(`raw id ${raw?.[`${this.schema.entity}_dataNode`]} ${id}`, raw);
    
    const { ok, message, data } = await this._resolveMosyResult(raw);

    // Same as create() — the API echoes back `${entity}_dataNode` on
    // success (e.g. sites_dataNode: "31"). We already know `id` here
    // since the caller passed it in, but return whatever the API
    // confirms so update()'s shape matches create()'s exactly and
    // callers can treat both the same way.
    const dataNodeKey = `${this.schema.entity}_dataNode`;
    const confirmedId = ok ? (raw?.[dataNodeKey] ?? id) : undefined;

    if (ok) {
      await this.load(); // keep the grid/list in sync with the edited row
    } else {
      this._setState({ error: message });
    }

    return { ok, message, data, id: confirmedId };
  }

  async remove(id) {
    // route.js's DELETE handler reads `${schema.entity}_delete` or `Node`
    // from the query string — it never looks for `id`. Sending `?id=`
    // meant tokenId came back null server-side, the delete ran against
    // an empty/garbage where-clause, and the route still happily
    // returned status:'success' since the query didn't error. `Node` is
    // the same alias getOne()/mosySecureSelect already use for this.
    const raw = await mosyPostData({ url: `${this.schema.apiBase}?Node=${btoa(id)}`, method: 'DELETE' });
    const { ok, message } = await this._resolveMosyResult(raw);

    if (ok) {
      await this.load();
    } else {
      this._setState({ error: message });
    }

    return { ok, message };
  }

  async runAction(actionKey) {
    const action = this.schema.actions?.find((a) => a.key === actionKey);
    if (!action) return { ok: false, message: `No action "${actionKey}" on schema.actions`, reload: false };
  
    const targetRows = action.appliesTo
      ? this.state.rows.filter((row) =>
          Object.entries(action.appliesTo).every(([k, v]) => row[k] === v)
        )
      : this.state.rows;
  
    const result = normalizeActionResult(
      // runRegisteredAction's signature is (moduleActions, key, ctx). This
      // was previously called as (action.key, ctx) — one arg short, so
      // every param shifted: moduleActions became the key STRING, key
      // became the ctx OBJECT, ctx was undefined. moduleActions[key] then
      // resolved to undefined every time, so the real handler never ran.
      // Passing this.moduleActions first fixes that.
      await runRegisteredAction(this.moduleActions, action.key, {
        rows: targetRows,
        schema: this.schema,
        refresh: () => this.load(),
        create: this.create.bind(this),
        update: this.update.bind(this),
        remove: this.remove.bind(this),
      })
    );
  
    // Anyone subscribed (not just whoever awaited the call) can react too —
    // e.g. a toast component watching c.lastAction.
    this._setState({ lastAction: { key: actionKey, ...result, at: Date.now() } });
  
    if (result.reload) await this.load();
    return result;
  }
  
  async runRowAction(actionKey, row, router) {
    const result = normalizeActionResult(
      // Same missing-argument bug as runAction() above — see the comment
      // there for the full explanation.
      await runRegisteredAction(this.moduleActions, actionKey, {
        rows: [row],
        schema: this.schema,
        router,
        refresh: () => this.load(),
        create: this.create.bind(this),
        update: this.update.bind(this),
        remove: this.remove.bind(this),
      })
    );
  
    this._setState({ lastAction: { key: actionKey, ...result, at: Date.now() } });
  
    if (result.reload) await this.load();
    return result;
  }
  
  // Call this when the UI unmounts / closes, to stop any pending debounce
  // and make sure any in-flight load() response gets ignored when it lands.
  destroy() {
    clearTimeout(this._searchDebounce);
    this._requestId++; // invalidates any response still in flight
    this.listeners.clear();
  }
}